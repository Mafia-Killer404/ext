# #PROHACK-FILE
<b></b> </br> <br>[![Github](https://img.shields.io/badge/Github-JAMES404-dimgray?style=flat-square&logo=github)](https://github.com/James404-cyber)<br> [![Facebook](https://img.shields.io/badge/Facebook-+JAMES-blue?style=flat-square&logo=facebook)](https://www.facebook.com/Apni.bapka.account7)<br> [![Instagram](https://img.shields.io/badge/Instagram-JAMES404-hotpink?style=flat-square&logo=instagram)](I'm on Instagram as @jame404404. Install the app to follow my photos and videos. https://www.instagram.com/invites/contact/?i=1xbkroj44l0gh&utm_content=2gx3kse)<br> [![Whatsapp](https://img.shields.io/badge/Whatsapp-James-deepgreen?style=flat-square&logo=whatsapp)](https://chat.whatsapp.com/Dy3uWB9hOsrCvu49DaKP1n)



<h1 align="center"> |ERROR PROBLEM FIXED |</h1>

<h1 align="center"> |MR.JAMES|</h1>

<h2 align="center"> FB CRACKING MULTYEP LOGIN </h2>


<h2 align="center"> LOGIN WITH FB ID, TOKEN,COOKIES </h2>

<p align="center">
      NEW FILE CLONING, PUBLIC AND FLOWERS CRACKING
</p>



<p align="center">
              MR.JAMES


## <b>installation</b>

```

$ pkg update
$ pkg upgrade
$ pkg install python
$ pkg install python2
$ termux-setup-storage 
$ rm -rf PROHACK-FILE 
$ pkg install nodejs 
$ pip2 install requests
$ pip2 install mechanize
$ pip2 install bs4
$ pkg install git
$ git clone https://github.com/James404-cyber/PROHACK-FILE.git
$ cd PROHACK-FILE 
$ python2 hackfile.py
```

# Single Command 

```
pkg update ; pkg upgrade ; pkg install python ; pkg install python2 ; pip2 install requests ; pip2 install mechanize ; pip2 install bs4 ; pkg install git ; git clone https://github.com/James404-cyber/PROHACK-FILE.git ; cd PROHACK-FILE ; python hackfile.py
```
[1]: Free Api Key : Black</br>

[2]: Free Api Key : Mnbvcxzlkjhgfdsa</br>
 
 [![Facebook](https://img.shields.io/badge/Facebook-JAMES-blue?style=flat-square&logo=facebook)](https://www.facebook.com/Apni.bapka.account7)</br>
